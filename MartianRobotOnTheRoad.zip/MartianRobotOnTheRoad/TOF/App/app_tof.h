/**
  ******************************************************************************
  * @file          : app_tof.h
  * @author        : IMG SW Application Team
  * @brief         : This file provides code for the configuration
  *                  of the STMicroelectronics.X-CUBE-TOF1.3.2.0 instances.
  ******************************************************************************
  *
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_TOF_H
#define __APP_TOF_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "53l5a1_ranging_sensor.h"

/* Exported defines ----------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/
void MX_TOF_Init(void);
void MX_TOF_Process(void);


/**
@brief Configure le capteur TOF (time-of-flight).
*/
void Setup_TOF(void);

/**
@brief Récupère la distance mesurée par le capteur TOF.
@param Result : Pointeur vers un objet RANGING_SENSOR_Result_t qui contiendra les résultats de mesure.
*/
void getDistance_TOF(RANGING_SENSOR_Result_t *Result);

/**
@brief Imprime les résultats de mesure obtenus par le capteur TOF.
@param Result : Pointeur vers un objet RANGING_SENSOR_Result_t qui contient les résultats de mesure.
*/
void print_result(RANGING_SENSOR_Result_t *Result);

/**
@brief Imprime les résultats de mesure obtenus par le capteur TOF, selon l'exemple d'application fournit un STM32 Cube MX.
@param Result : Pointeur vers un objet RANGING_SENSOR_Result_t qui contient les résultats de mesure.
*/
void old_print_result(RANGING_SENSOR_Result_t *Result);

#ifdef __cplusplus
}
#endif

#endif /* __APP_TOF_H */
