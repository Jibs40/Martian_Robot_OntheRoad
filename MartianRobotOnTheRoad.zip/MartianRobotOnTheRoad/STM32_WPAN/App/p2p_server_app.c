/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    p2p_server_app.c
  * @author  MCD Application Team
  * @brief   Peer to peer Server Application
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2019-2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "app_common.h"
#include "dbg_trace.h"
#include "ble.h"
#include "p2p_server_app.h"
#include "stm32_seq.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//#include "app_tof.h"
#include "NanoEdgeAI.h"
#include "knowledge.h"
#include <stdbool.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/**
@struct P2P_SENSORS_CharValue_t
@brief Cette structure contient les valeurs du capteur TOF et la direction du robot.
*/
typedef struct{
    uint8_t             TOF;
    uint8_t             Robot_Direction;
 }P2P_SENSORS_CharValue_t;


/**
@struct P2P_Server_App_Context_t
@brief Structure de contexte de l'application du serveur P2P
Cette structure contient les informations nécessaires pour gérer les notifications
et les valeurs des capteurs de l'application P2P.
@var P2P_Server_App_Context_t::Notification_Status
Indicateur pour vérifier si le serveur P2P est activé pour les notifications.
@var P2P_Server_App_Context_t::Sensors_Values
Structure de valeurs de capteurs pour l'application P2P.
@var P2P_Server_App_Context_t::ConnectionHandle
Identifiant de connexion.
@var P2P_Server_App_Context_t::TimerMeasurement_Id
Identifiant du timer lié à l'envoi de notifications.
*/

typedef struct{
  uint8_t               	Notification_Status; /* used to check if P2P Server is enabled to Notify */
  P2P_SENSORS_CharValue_t   Sensors_Values;
  uint16_t              	ConnectionHandle;
  uint8_t 					TimerMeasurement_Id;
} P2P_Server_App_Context_t;

#define MEASUREMENT_INTERVAL   (1000000/CFG_TS_TICK_VAL)  /**< 1s */

/**

@brief Définit la période de la tâche de la mesure de la distance avec le TOF en millisecondes, utilisés par le séquenceur "task_scheduler".
@def TOF_TASK_PERIOD_MS
@var 500
*/
/**
@brief Définit la période de la tâche de la détection de la ligne noire en millisecondes, utilisés par le séquenceur "task_scheduler".
@def BLACK_LINE_TASK_PERIOD_MS
@var 50
*/
#define TOF_TASK_PERIOD_MS 300
#define BLACK_LINE_TASK_PERIOD_MS 50
#define FORBID_CLASS 2

/* USER CODE END PTD */

/* Private defines ------------------------------------------------------------*/
/* USER CODE BEGIN PD */



/**

@brief Booléen indiquant si l'initialisation du capteur TOf a été effectuée
Valeur par défaut : false
*/
bool flag_initTOF_done = false;
/**

@brief Booléen indiquant si l'initialisation des capteurs IRs a été effectuée
Valeur par défaut : false
*/
bool flag_initIRs_done = false;

/* USER CODE END PD */

/* Private macros -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
/**
 * START of Section BLE_APP_CONTEXT
 */

static P2P_Server_App_Context_t P2P_Server_App_Context;

/**
 * END of Section BLE_APP_CONTEXT
 */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void P2PS_APP_Init(void);
void P2PS_APP_SENSORS_Init(void);
void TOF_Measurement(void);
void BLACKLINE_Detection(void);


/**
@brief Scheduler pour la détection de la ligne noire et la mesure TOF
Cette fonction gère les compteurs pour appeler les fonctions de mesure TOF et de détection de la ligne noire.
Les compteurs sont incrémentés à chaque appel de la fonction et les fonctions correspondantes sont appelées
si le compteur atteint la période définie (TOF_TASK_PERIOD_MS et BLACK_LINE_TASK_PERIOD_MS).
*/

void TOF_LINEDETECTION_scheduler(void) {
	static uint32_t tof_task_counter = 0;
	static uint32_t black_line_task_counter = 0;

	tof_task_counter += 1;
		if (tof_task_counter >= (TOF_TASK_PERIOD_MS / BLACK_LINE_TASK_PERIOD_MS)) {
		tof_task_counter = 0;
		TOF_Measurement();
		}

		black_line_task_counter += 1;

		if (black_line_task_counter >= (BLACK_LINE_TASK_PERIOD_MS / BLACK_LINE_TASK_PERIOD_MS)) {
		black_line_task_counter = 0;
		BLACKLINE_Detection();
		}
}


/**
@brief Remplit le buffer d'entrée utilisateur avec les résultats de la distance mesurée par le capteur de distance.
@param Result : Pointeur vers les résultats de la mesure de distance.
@param buffer : Tableau pour stocker les données de la distance mesurée.
*/

void fill_buffer(RANGING_SENSOR_Result_t *Result, float buffer[]){
	int i;
	for (i = 0; i < DATA_INPUT_USER; i++) {
		buffer[i] = (float) Result->ZoneResult[i].Distance[0];
	}
}

/**
@brief Cette fonction effectue la détection de la ligne noire par le robot.
Elle utilise la valeur renvoyée par la fonction readLine() pour déterminer la direction à prendre.
En fonction de la valeur de la ligne, le robot peut tourner à gauche ou à droite ou avancer tout droit.
La vitesse des deux roues du robot est également modifiée pour prendre la bonne direction.
La fonction utilise également les fonctions Move_Left_wheel_Forward() et Move_Right_wheel_Forward() pour contrôler la vitesse des roues.
La fonction est appelée périodiquement par le scheduler TOF_LINEDETECTION_scheduler().
*/




void BLACKLINE_Detection(void){
	int line_value = 0;

	line_value = readLine(1);
	DBG_PRINT("LINE VALUE : %d\n", line_value);


	if (line_value>=700 && line_value<1400){
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else {
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MAX_SPEED);
			//DBG_PRINT("GAUCHE FORT\n");
		}
	}


	else if (line_value>=1400 && line_value<1600){
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else{
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);

			Move_Left_wheel_Forward(MAX_SPEED-2);
			Move_Right_wheel_Forward(MAX_SPEED);
			//DBG_PRINT("GAUCHE\n");
			}
	}

	else if (line_value>=1600 && line_value<2300) {
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else{
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
			Move_Left_wheel_Forward(MAX_SPEED);
			Move_Right_wheel_Forward(MAX_SPEED);
			//DBG_PRINT("TOUT DROIT\n");
		}
	}

	else if (line_value>=2300&& line_value<2600){
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else{
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);

			Move_Left_wheel_Forward(MAX_SPEED);
			Move_Right_wheel_Forward(MAX_SPEED-2);
			//DBG_PRINT("DROITE\n");
		}
	}

	else if (line_value>=2600 && line_value<3300){
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else{
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
			Move_Left_wheel_Forward(MAX_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			//DBG_PRINT("DROITE FORT\n");
		}
	}
	else {
		if (id_class == FORBID_CLASS){ 						// Carré
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
			Move_Left_wheel_Forward(MIN_SPEED);
			Move_Right_wheel_Forward(MIN_SPEED);
			HAL_Delay(1000);
		}
		else{
			HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
			Move_Left_wheel_Forward(MAX_SPEED-3);
			Move_Right_wheel_Forward(MIN_SPEED);
		}
	}
	HAL_Delay(100);
}


/* USER CODE END PFP */

/**
 * @brief Gère les notifications pour l'application BLE de serveur P2P (Peer-to-Peer).
 * Elle prend en entrée un pointeur sur un événement de notification (P2PS_STM_App_Notification_evt_t *pNotification).
 * L'opcode dans l'événement est utilisé pour déterminer le type d'événement et agir en conséquence.
 * Les événements gérés incluent:
 * - P2PS_STM_BOOT_REQUEST_EVT: une demande de redémarrage est reçue, le système est redémarré
 * - P2PS_STM__NOTIFY_ENABLED_EVT: les notifications sont activées, un minuteur est démarré pour envoyer des valeurs de notification toutes les secondes
 * - P2PS_STM_NOTIFY_DISABLED_EVT: les notifications sont désactivées, le minuteur est arrêté
 * - P2PS_STM_WRITE_EVT: un événement d'écriture est reçu, la direction du robot est modifiée en fonction des données reçues
 * HW_TS_Start, HW_TS_Stop et P2PS_STM_App_Update_Char sont utilisées pour envoyer les données du capteur sur l'IHM périodiquement.
 */


/* Functions Definition ------------------------------------------------------*/
void P2PS_STM_App_Notification(P2PS_STM_App_Notification_evt_t *pNotification){

/* USER CODE BEGIN P2PS_STM_App_Notification_1 */

/* USER CODE END P2PS_STM_App_Notification_1 */
  switch(pNotification->P2P_Evt_Opcode)  {
/* USER CODE BEGIN P2PS_STM_App_Notification_P2P_Evt_Opcode */
#if(BLE_CFG_OTA_REBOOT_CHAR != 0)
    case P2PS_STM_BOOT_REQUEST_EVT:
    	DBG_PRINT("-- P2P APPLICATION SERVER : BOOT REQUESTED\n");
    	DBG_PRINT(" \n\r");

      *(uint32_t*)SRAM1_BASE = *(uint32_t*)pNotification->DataTransfered.pPayload;
      NVIC_SystemReset();
      break;
#endif
/* USER CODE END P2PS_STM_App_Notification_P2P_Evt_Opcode */

    case P2PS_STM__NOTIFY_ENABLED_EVT:
/* USER CODE BEGIN P2PS_STM__NOTIFY_ENABLED_EVT */
    	/* Notifications activated */
      P2P_Server_App_Context.Notification_Status = 1;
      DBG_PRINT("-- P2P APPLICATION SERVER : NOTIFICATION ENABLED\n");

      /* Values of TOF Notification are send every second */
      HW_TS_Stop(P2P_Server_App_Context.TimerMeasurement_Id);
      HW_TS_Start(P2P_Server_App_Context.TimerMeasurement_Id, MEASUREMENT_INTERVAL);

/* USER CODE END P2PS_STM__NOTIFY_ENABLED_EVT */
      break;

    case P2PS_STM_NOTIFY_DISABLED_EVT:
    	/* USER CODE BEGIN P2PS_STM_NOTIFY_DISABLED_EVT */

	/* Notification are desactivated */
	P2P_Server_App_Context.Notification_Status = 0;
	DBG_PRINT("-- P2P APPLICATION SERVER : NOTIFICATION DISABLED\n");
	DBG_PRINT(" \n\r");
	// Arret des moteurs des routes
	Stop();
	// Reinitialisation des flags
	if (flag_initTOF_done == true)
    	flag_initTOF_done = false;
	if (flag_initIRs_done == true)
		flag_initIRs_done = false;

	/* Timer is stopped */
	HW_TS_Stop(P2P_Server_App_Context.TimerMeasurement_Id);

#if (BLE_CFG_OTA_REBOOT_CHAR != 0)
    case P2PS_STM_BOOT_REQUEST_EVT:
/* USER CODE BEGIN HRS_STM_BOOT_REQUEST_EVT */
      *(uint32_t*)SRAM1_BASE = *(uint32_t*)pNotification->DataTransfered.pPayload;
      NVIC_SystemReset();
/* USER CODE END HRS_STM_BOOT_REQUEST_EVT */
      break;
#endif
/* USER CODE END P2PS_STM_NOTIFY_DISABLED_EVT */
      break;

    case P2PS_STM_WRITE_EVT:

/* USER CODE BEGIN P2PS_STM_WRITE_EVT */
#if(P2P_SERVER1 != 0)
    	DBG_PRINT("-- P2P STM WRITE EVENT ENABLED\n");
    	DBG_PRINT("-- Controle moteur actif\n");
     // if(pNotification->DataTransfered.pPayload[0] == 0x01){ /* end device 1 selected - may be necessary as LB Routeur informs all connection */
        if(pNotification->DataTransfered.pPayload[1] == 0x01){
        	DBG_PRINT("-- En avant\n");
			Move_Left_wheel_Forward(MAX_SPEED);
			Move_Right_wheel_Forward(MAX_SPEED);
			P2P_Server_App_Context.Sensors_Values.Robot_Direction=1<<4;
            P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.Robot_Direction);
        }
        if(pNotification->DataTransfered.pPayload[1] == 0x02){
        	DBG_PRINT("-- A droite\n");
			Move_Left_wheel_Forward(MAX_SPEED);
			Move_Right_wheel_Forward(MAX_SPEED-3);
        	P2P_Server_App_Context.Sensors_Values.Robot_Direction=2<<4;
			P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.Robot_Direction);
		}
        if(pNotification->DataTransfered.pPayload[1] == 0x03){
        	DBG_PRINT("-- A gauche\n");
			Move_Left_wheel_Forward(MAX_SPEED-3);
			Move_Right_wheel_Forward(MAX_SPEED);
        	P2P_Server_App_Context.Sensors_Values.Robot_Direction=3<<4;
			P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.Robot_Direction);
		}
        if(pNotification->DataTransfered.pPayload[1] == 0x04){
        	DBG_PRINT("-- En arriere\n");
        	Move_Left_wheel_Backward(MAX_SPEED);
        	Move_Right_wheel_Backward(MAX_SPEED);
        	P2P_Server_App_Context.Sensors_Values.Robot_Direction=4<<4;
			P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.Robot_Direction);
		}

        if(pNotification->DataTransfered.pPayload[1] == 0x05){
        	DBG_PRINT("-- Black Line Detection + TOF\n");
        	if (flag_initIRs_done == false){
        		calibrate_IR();
        		flag_initIRs_done = true;
        	}
        	if (flag_initIRs_done == true){
        		while(1){
        			TOF_LINEDETECTION_scheduler();
        		}
        	}
        }
        if(pNotification->DataTransfered.pPayload[1] == 0x00){
        	DBG_PRINT("-- Stop\n");
        	Stop();
			P2P_Server_App_Context.Sensors_Values.Robot_Direction=0<<4;
			P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.Robot_Direction);
        }

#endif

/* USER CODE END P2PS_STM_WRITE_EVT */
      break;

    default:
/* USER CODE BEGIN P2PS_STM_App_Notification_default */

/* USER CODE END P2PS_STM_App_Notification_default */
      break;
  }
/* USER CODE BEGIN P2PS_STM_App_Notification_2 */

/* USER CODE END P2PS_STM_App_Notification_2 */
  return;
}


/**
 * @brief Gère les notifications d'événements liées à la connexion P2P.
 * Elle utilise un pointeur vers une structure "P2PS_APP_ConnHandle_Not_evt_t" pour obtenir l'opcode de l'événement.
 * L'opcode peut être :
 * - "PEER_CONN_HANDLE_EVT" pour indiquer que le client est connecté
 * - "PEER_DISCON_HANDLE_EVT" pour indiquer que le client est déconnecté.
 * @param pNotification
 */

void P2PS_APP_Notification(P2PS_APP_ConnHandle_Not_evt_t *pNotification){
/* USER CODE BEGIN P2PS_APP_Notification_1 */

/* USER CODE END P2PS_APP_Notification_1 */
  switch(pNotification->P2P_Evt_Opcode)  {
/* USER CODE BEGIN P2PS_APP_Notification_P2P_Evt_Opcode */

/* USER CODE END P2PS_APP_Notification_P2P_Evt_Opcode */
  case PEER_CONN_HANDLE_EVT :
/* USER CODE BEGIN PEER_CONN_HANDLE_EVT */
	DBG_PRINT("-- P2P APPLICATION SERVER : CLIENT CONNECTE\n");
/* USER CODE END PEER_CONN_HANDLE_EVT */
    break;

    case PEER_DISCON_HANDLE_EVT :
/* USER CODE BEGIN PEER_DISCON_HANDLE_EVT */
	DBG_PRINT("-- P2P APPLICATION SERVER : CLIENT DECONNECTE\n");
	if (flag_initTOF_done == true)
		flag_initTOF_done = false;
	if (flag_initIRs_done == true)
		flag_initIRs_done = false;

/* USER CODE END PEER_DISCON_HANDLE_EVT */
    break;

    default:
/* USER CODE BEGIN P2PS_APP_Notification_default */

/* USER CODE END P2PS_APP_Notification_default */
      break;
  }
/* USER CODE BEGIN P2PS_APP_Notification_2 */

/* USER CODE END P2PS_APP_Notification_2 */
  return;
}

/**
 * @brief La fonction TOFMeas est une fonction statique qui définit un ensemble de tâches.
 * Cela est fait en utilisant la fonction UTIL_SEQ_SetTask en passant en argument un masque de bits 1<<CFG_TASK_MEAS_REQ
 * et une priorité de planification CFG_SCH_PRIO_0.
 */

static void TOFMeas(void){
	UTIL_SEQ_SetTask( 1<<CFG_TASK_MEAS_REQ, CFG_SCH_PRIO_0);
	return;
}

/**
@brief Routine de mesure de distance TOF
La routine effectue les actions suivantes:
- Allume la LED LD3 pour indiquer le début de la mesure de distance.
- Effectue l'initialisation de l'algorithme d'apprentissage si nécessaire.
- Mesure la distance avec la fonction getDistance_TOF().
- Effectue la classification en utilisant la fonction neai_classification()
- Transfère la valeur de classe détectée obtenue par la classification dans P2P_Server_App_Context.Sensors_Values.TOF.
- Éteint la LED LD3 pour indiquer la fin de la mesure de distance
*/

/* USER CODE BEGIN FD */
void TOF_Measurement(void){
	DBG_PRINT("--- SUIVI DE LIGNE ET MESURE TOF\n");
	HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_SET);
    RANGING_SENSOR_Result_t Result;
    enum neai_state error_code;

	/* Apprentissage du capteur (uniquement au démarrage) */
    if (flag_initTOF_done == false){
    	flag_initTOF_done = true;

	error_code = neai_classification_init(knowledge);
		if(error_code!= NEAI_OK){
			DBG_PRINT("ERROR : Apprentissage\n");
		}
		else{
			DBG_PRINT("SUCCESS : Apprentissage\n");
		}
    }
    else{
    	/* Mesure de distance */
    	getDistance_TOF(&Result);
		/* Rempli le buffer de classification avec les mesures */
		fill_buffer(&Result, input_user_buffer);
		/* Classification des mesures, renvoi des probabilités dans le buffer output, et l'id de la classe avec la meilleure probabilité */
		neai_classification(input_user_buffer, output_class_buffer, &id_class);
		DBG_PRINT("Idclass: %d\n",id_class);
		DBG_PRINT("Classe Detectee: %s (Probabilite: %d%%)\n",
			id2class[id_class],
			(uint16_t) (output_class_buffer[id_class - 1] * 100));
		/* Transfert des valeurs via BLE */
		P2P_Server_App_Context.Sensors_Values.TOF=id_class<<4;
		P2PS_STM_App_Update_Char(P2P_NOTIFY_CHAR_UUID, (uint8_t *)&P2P_Server_App_Context.Sensors_Values.TOF);
		HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);

    }
}

/**

@brief Initialise l'application serveur P2P
Cette fonction initialise toutes les variables, enregistre la tâche de mesure TOF et crée un timer pour envoyer les valeurs toutes les secondes.
*/

void P2PS_APP_Init(void)
{
/* USER CODE BEGIN P2PS_APP_Init */
	UTIL_SEQ_RegTask(1<< CFG_TASK_MEAS_REQ, UTIL_SEQ_RFU, TOF_Measurement);

	/* Initialisation of all the variables */
	P2P_Server_App_Context.Notification_Status=0;
	P2P_Server_App_Context.Sensors_Values.TOF=0;
	P2P_Server_App_Context.Sensors_Values.Robot_Direction=0;

	if (flag_initTOF_done == true)
    	flag_initTOF_done = false;
	if (flag_initIRs_done == true)
		flag_initIRs_done = false;

	/* Creation of a timer to send the values every second */
  HW_TS_Create(CFG_TIM_PROC_ID_ISR, &(P2P_Server_App_Context.TimerMeasurement_Id), hw_ts_Repeated, TOFMeas);

	/* USER CODE END P2PS_APP_Init */
  return;
}



